# Meher Cuisine

A bilingual (English / Bangla) restaurant website with an admin dashboard, table reservations and online ordering,
built with Laravel, Tailwind CSS (Vite), JavaScript + jQuery and MySQL.

## Features

**Public site:** home, menu (search, categories, pagination, sizes and extras), dish pages, about, gallery with lightbox,
offers, reviews, FAQ, contact form, newsletter, privacy and terms pages, custom 403/404/419/429/500 pages.
**Reservations:** capacity-based availability, overlap checks, status workflow and emails.
**Ordering:** server-priced cart, coupons, delivery or pickup, cash or online payment (SSLCommerz), order tracking.
**Admin** (`/admin`): dashboard, reservations, orders, messages, menu and categories, gallery, offers, testimonials,
FAQ, team, coupons, subscribers (CSV export), site settings, users and roles, activity log.
**Quality:** automated tests, security headers (CSP, HSTS), WebP image processing, sitemap, robots.txt, Schema.org data.

## Requirements

PHP (the version in `composer.json`) with the extensions: mbstring, openssl, pdo_mysql, tokenizer, xml, ctype,
fileinfo, curl, bcmath and **gd with WebP support**; Composer; Node.js and npm; MySQL or MariaDB (utf8mb4).

## Local setup (Windows / XAMPP)

```bash
composer install
copy .env.example .env          # macOS/Linux: cp .env.example .env
php artisan key:generate
```

Create an empty database named `meher` (collation `utf8mb4_unicode_ci`) in phpMyAdmin and set `DB_*` in `.env`, then:

```bash
php artisan migrate --seed      # prints the admin password ONCE: save it
php artisan db:seed --class=OptionSeeder   # optional: sample sizes and extras for Kacchi Biryani
php artisan storage:link
npm install
```

Run these in separate terminals:

```bash
npm run dev            # assets with hot reload
php artisan serve      # http://127.0.0.1:8000
php artisan queue:work # sends queued emails (with MAIL_MAILER=log they appear in storage/logs/laravel.log)
```

Admin login: `http://127.0.0.1:8000/admin/login`. If styles disappear after you stop `npm run dev`, delete `public/hot`.

## Admin roles

| Role    | Can do                                                            |
| ------- | ----------------------------------------------------------------- |
| Admin   | Everything, including settings, users and the activity log        |
| Manager | Menu, content, coupons, subscribers, plus everything Staff can do |
| Staff   | Reservations, orders and messages                                 |

## Configuration

Everything configurable is in `.env` (see `.env.example`, every key has a comment). Business details that change often
(name, cuisine, hours, phone, address, social links, map) are edited in **Admin > Settings**, in English and Bangla.

| Area         | Keys                                                                                                                         |
| ------------ | ---------------------------------------------------------------------------------------------------------------------------- |
| Ordering     | `ORDERING_ENABLED`, `ORDER_DELIVERY`, `ORDER_PICKUP`, `DELIVERY_FEE`, `FREE_DELIVERY_OVER`, `MIN_ORDER`, `ORDER_ALERT_EMAIL` |
| Reservations | `RESERVATION_CAPACITY`, `RESERVATION_DURATION`, `RESERVATION_OPEN`, `RESERVATION_LAST_SEATING`                               |
| Payment      | `ONLINE_PAYMENT`, `SSLCOMMERZ_STORE_ID`, `SSLCOMMERZ_STORE_PASSWORD`, `SSLCOMMERZ_SANDBOX`                                   |
| Security     | `SECURITY_CSP`, `SESSION_*`                                                                                                  |

Use `env()` only inside `config/*.php`. After changing `.env` on a server that caches config, run `php artisan config:cache`.

## Tests

```bash
php artisan test
```

Tests run on SQLite in memory (enable `pdo_sqlite` and `sqlite3` in `php.ini`) and refuse to run against any other
database unless its name ends in `_test`.

## Useful commands

| Command                                                | Purpose                                                                                   |
| ------------------------------------------------------ | ----------------------------------------------------------------------------------------- |
| `php artisan app:preflight`                            | Checks production settings before going live                                              |
| `php artisan orders:expire-unpaid`                     | Cancels online orders unpaid after `UNPAID_ORDER_EXPIRY` minutes (scheduled every 10 min) |
| `php artisan db:seed --class=ProductionSeeder --force` | Creates only the admin account and settings on a live server                              |

## Deployment

See [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md) (VPS and shared hosting, HTTPS, mail, queue, backups, going live with payments).

## Known limitations

- The language is stored in the session, not in the URL, so search engines index the English pages only.
- Opening hours are free text (no structured hours in the Schema.org data).
- No two-factor login for admins; use strong, unique passwords.
- Extras are checkboxes (no quantity per extra).
- Refunds are made in the SSLCommerz merchant panel, not from the admin.
- Adding a third language needs new database columns (`*_xx`) and language files.
