<?php

use App\Models\RestaurantSetting;

use Illuminate\Support\Facades\Storage;


if (! function_exists('setting')) {
    function setting(string $key, ?string $default = null): ?string
    {
        return RestaurantSetting::get($key, $default);
    }
}

if (! function_exists('money')) {
    /** Format an amount in currency units, e.g. 380 => "৳ 380". */
    function money(int|float|string $amount): string
    {
        $amount = (float) $amount;
        $whole = abs($amount - round($amount)) < 0.005;

        return config('restaurant.currency_symbol') . ' ' . number_format($amount, $whole ? 0 : 2);
    }
}

if (! function_exists('money_c')) {
    /** Format an amount given in paisa (integer cents). */
    function money_c(int $cents): string
    {
        return money($cents / 100);
    }
}

if (! function_exists('image_thumb')) {
    /** URL of the 480px thumbnail made by ImageService, or null for older uploads that have none. */
    function image_thumb(?string $path): ?string
    {
        if (! $path || ! str_ends_with($path, '.webp')) {
            return null;
        }

        $thumb = substr($path, 0, -5) . '-480.webp';
        $disk = Storage::disk('public');

        return $disk->exists($thumb) ? $disk->url($thumb) : null;
    }
}

if (! function_exists('section_theme')) {
    /** Background color of a frontend section plus whether it needs light text. */
    function section_theme(string $key): array
    {
        $default = \App\Support\Sections::all()[$key]['default'] ?? '#FAF7F2';
        $custom = setting('color_' . $key);
        $bg = \App\Support\Color::isHex($custom) ? strtoupper($custom) : $default;

        return ['bg' => $bg, 'dark' => \App\Support\Color::wantsLightText($bg)];
    }
}

if (! function_exists('setting_image')) {
    /** Public URL of an image stored in a setting (logo, favicon, owner photo), or null. */
    function setting_image(string $key): ?string
    {
        $path = setting($key);

        return $path ? Storage::disk('public')->url($path) : null;
    }
}

if (! function_exists('whatsapp_link')) {
    /** wa.me link from the WhatsApp settings, or null when the button is off or the number is missing. */
    function whatsapp_link(?string $text = null): ?string
    {
        if (setting('whatsapp_enabled') !== '1') {
            return null;
        }

        $number = preg_replace('/\D/', '', (string) setting('whatsapp_number'));

        if (strlen($number) < 8) {
            return null;
        }

        $text ??= setting('whatsapp_message');

        return 'https://wa.me/' . $number . ($text ? '?text=' . rawurlencode($text) : '');
    }
}

if (! function_exists('qty')) {
    /** A quantity without useless trailing zeros: 250.000 => 250, 0.300 => 0.3 */
    function qty(int|float|string|null $value): string
    {
        $text = rtrim(rtrim(number_format((float) $value, 3, '.', ','), '0'), '.');

        return in_array($text, ['', '-'], true) ? '0' : $text;
    }
}

if (! function_exists('setting_en')) {
    /** The English value of a setting, for documents such as PDFs that cannot show Bangla. */
    function setting_en(string $key, ?string $default = null): ?string
    {
        $value = \App\Models\RestaurantSetting::cached()[$key]['en'] ?? null;

        return filled($value) ? $value : $default;
    }
}

if (! function_exists('pdf_money')) {
    function pdf_money(int|float|string $amount): string
    {
        return config('restaurant.pdf_currency', 'Tk') . ' ' . number_format((float) $amount, 2);
    }
}

if (! function_exists('seo_meta')) {
    /** Final title, description and image for the page being shown, with the admin's SEO settings applied. */
    function seo_meta(?string $title, ?string $description, ?string $image): array
    {
        $site = setting('name', config('app.name'));
        $keys = [
            'home' => 'home',
            'menu.index' => 'menu',
            'about' => 'about',
            'gallery' => 'gallery',
            'offers' => 'offers',
            'testimonials' => 'testimonials',
            'faq' => 'faq',
            'contact.create' => 'contact',
            'reservations.create' => 'reservations',
        ];
        $key = $keys[request()->route()?->getName() ?? ''] ?? null;

        return [
            'title' => ($key ? setting("seo_{$key}_title") : null) ?: (($title ? $title . ' | ' : '') . $site),
            // 'description' => ($key ? setting("seo_{$key}_description") : null)
            //     ?: ($description ?: (setting('seo_default_description') ?: (string) setting('tagline', ''))),

            'description' => ($key ? setting("seo_{$key}_description") : null)
                ?: (setting('seo_default_description') ?: ($description ?: (string) setting('tagline', ''))),
            'image' => $image ?: setting_image('seo_default_image'),
            'noindex' => setting('seo_noindex_all') === '1',
            'google' => setting('seo_google_verification'),
            'bing' => setting('seo_bing_verification'),
        ];
    }
}

if (! function_exists('https_forced')) {
    /** Links are forced to https on a real production site, but not when it runs on the restaurant's own network. */
    function https_forced(): bool
    {
        return app()->isProduction() && ! config('restaurant.lan_mode');
    }
}
